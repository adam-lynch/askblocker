## Icon credits

- 001-circular-counterclockwise-arrows.svg is by Plainicon from Flaticon.
- 001-creative-commons-license-symbol.svg is by Simpleicon from Flaticon.
- 002-github-logo.svg is by Dave Gandy from Flaticon.
- 004-karaoke-microphone-icon.svg is by Bogdan Rosu from Flaticon.
- 006-photo-camera.svg is by Dave Gandy from Flaticon.
- 007-database.svg is by Smashicons from Flaticon.
- 008-signs.svg is by Chris Veigt from Flaticon.
- 009-piano.svg is by Pixel perfect from Flaticon.
- 010-facebook-placeholder-for-locate-places-on-maps.svg is by SimpleIcon from Flaticon.
- 011-sound.svg is by Google from Flaticon.
- The AskBlocker icons were created by me. Do whatever you want with them.